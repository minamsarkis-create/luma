import { useState, useEffect } from 'react';
import {
  MapPin,
  Phone,
  Clock,
  Star,
  Instagram,
  ArrowRight,
  Menu,
  X,
  ChevronDown,
  Utensils,
  Music,
  Wine,
} from 'lucide-react';

export default function App() {
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [activeSection, setActiveSection] = useState('home');

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
      const sections = ['home', 'about', 'menu', 'reviews', 'contact'];
      const current = sections.find((section) => {
        const element = document.getElementById(section);
        if (element) {
          const rect = element.getBoundingClientRect();
          return rect.top <= 100 && rect.bottom >= 100;
        }
        return false;
      });
      if (current) setActiveSection(current);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
    setMobileMenuOpen(false);
  };

  return (
    <div className="font-sans text-charcoal-900 bg-cream-50">
      <Navigation
        isScrolled={isScrolled}
        mobileMenuOpen={mobileMenuOpen}
        setMobileMenuOpen={setMobileMenuOpen}
        scrollToSection={scrollToSection}
        activeSection={activeSection}
      />
      <Hero scrollToSection={scrollToSection} />
      <About />
      <MenuSection />
      <Reviews />
      <Contact />
      <Footer />
    </div>
  );
}

interface NavigationProps {
  isScrolled: boolean;
  mobileMenuOpen: boolean;
  setMobileMenuOpen: (open: boolean) => void;
  scrollToSection: (section: string) => void;
  activeSection: string;
}

function Navigation({
  isScrolled,
  mobileMenuOpen,
  setMobileMenuOpen,
  scrollToSection,
  activeSection,
}: NavigationProps) {
  const navItems = [
    { id: 'home', label: 'Home' },
    { id: 'about', label: 'About' },
    { id: 'menu', label: 'Menu' },
    { id: 'reviews', label: 'Reviews' },
    { id: 'contact', label: 'Contact' },
  ];

  return (
    <nav
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ${
        isScrolled
          ? 'bg-charcoal-950/95 backdrop-blur-md shadow-xl'
          : 'bg-transparent'
      }`}
    >
      <div className="max-w-7xl mx-auto px-6 lg:px-8">
        <div className="flex items-center justify-between h-20">
          <button
            onClick={() => scrollToSection('home')}
            className="font-display text-3xl font-bold tracking-wide text-white hover:text-gold-400 transition-colors"
          >
            LUMA
          </button>
          <div className="hidden md:flex items-center gap-8">
            {navItems.map((item) => (
              <button
                key={item.id}
                onClick={() => scrollToSection(item.id)}
                className={`relative text-sm font-medium tracking-wide transition-colors py-2 ${
                  activeSection === item.id
                    ? 'text-gold-400'
                    : 'text-white/80 hover:text-white'
                }`}
              >
                {item.label}
                <span
                  className={`absolute bottom-0 left-0 right-0 h-0.5 bg-gold-400 transition-transform duration-300 ${
                    activeSection === item.id ? 'scale-x-100' : 'scale-x-0'
                  }`}
                />
              </button>
            ))}
            <a
              href="tel:+201288883307"
              className="bg-gold-500 hover:bg-gold-600 text-charcoal-900 px-6 py-2.5 rounded-sm font-semibold text-sm tracking-wide transition-all duration-300 hover:shadow-lg hover:shadow-gold-500/20"
            >
              Reserve Now
            </a>
          </div>
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="md:hidden text-white p-2"
          >
            {mobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>
      </div>
      {mobileMenuOpen && (
        <div className="md:hidden bg-charcoal-950/98 backdrop-blur-lg border-t border-charcoal-800">
          <div className="px-6 py-4 space-y-4">
            {navItems.map((item) => (
              <button
                key={item.id}
                onClick={() => scrollToSection(item.id)}
                className={`block w-full text-left py-3 text-lg font-medium transition-colors ${
                  activeSection === item.id
                    ? 'text-gold-400'
                    : 'text-white/80 hover:text-white'
                }`}
              >
                {item.label}
              </button>
            ))}
            <a
              href="tel:+201288883307"
              className="block w-full text-center bg-gold-500 hover:bg-gold-600 text-charcoal-900 px-6 py-3 rounded-sm font-semibold tracking-wide transition-colors mt-4"
            >
              Reserve Now
            </a>
          </div>
        </div>
      )}
    </nav>
  );
}

function Hero({ scrollToSection }: { scrollToSection: (section: string) => void }) {
  return (
    <section id="home" className="relative min-h-screen flex items-center justify-center overflow-hidden">
      <div className="absolute inset-0">
        <img
          src="https://images.pexels.com/photos/1516983/pexels-photo-1516983.jpeg?auto=auto=compress&cs=tinysrgb&w=1920"
          alt="Restaurant ambiance"
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-charcoal-950/40 via-charcoal-950/60 to-charcoal-950/80" />
      </div>
      <div className="relative z-10 max-w-7xl mx-auto px-6 lg:px-8 text-center">
        <div className="animate-fade-in opacity-0">
          <p className="text-gold-400 text-sm md:text-base font-medium tracking-[0.3em] uppercase mb-6">
            Fine Dining & Cocktails
          </p>
        </div>
        <h1 className="font-display text-6xl md:text-8xl lg:text-9xl font-bold text-white mb-6 animate-slide-up opacity-0 delay-200">
          LUMA
        </h1>
        <p className="text-white/90 text-lg md:text-xl lg:text-2xl font-light max-w-2xl mx-auto mb-8 leading-relaxed animate-slide-up opacity-0 delay-400">
          An unforgettable culinary experience in the heart of Hurghada
        </p>
        <div className="flex flex-col sm:flex-row gap-4 justify-center items-center animate-slide-up opacity-0 delay-600">
          <button
            onClick={() => scrollToSection('menu')}
            className="bg-gold-500 hover:bg-gold-600 text-charcoal-900 px-8 py-4 rounded-sm font-semibold tracking-wide transition-all duration-300 hover:shadow-xl hover:shadow-gold-500/30 flex items-center gap-2 group"
          >
            Explore Menu
            <ArrowRight size={18} className="group-hover:translate-x-1 transition-transform" />
          </button>
          <button
            onClick={() => scrollToSection('contact')}
            className="border-2 border-white/30 hover:border-white text-white px-8 py-4 rounded-sm font-semibold tracking-wide transition-all duration-300 hover:bg-white/10"
          >
            Make Reservation
          </button>
        </div>
        <div className="absolute bottom-12 left-1/2 -translate-x-1/2 animate-bounce">
          <ChevronDown size={32} className="text-white/60 cursor-pointer" onClick={() => scrollToSection('about')} />
        </div>
      </div>
      <div className="absolute bottom-0 left-0 right-0 h-32 bg-gradient-to-t from-cream-50 to-transparent" />
    </section>
  );
}

function About() {
  const features = [
    { icon: <Utensils size={32} />, title: 'Exquisite Cuisine', description: 'Mediterranean-inspired dishes crafted with local ingredients' },
    { icon: <Wine size={32} />, title: 'Artisan Cocktails', description: 'Curated selection of classic and signature cocktails' },
    { icon: <Music size={32} />, title: 'Live Music', description: 'Weekly performances creating the perfect atmosphere' },
  ];

  return (
    <section id="about" className="py-24 lg:py-32 bg-cream-50">
      <div className="max-w-7xl mx-auto px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-16 lg:gap-20 items-center">
          <div className="order-2 lg:order-1">
            <div className="relative">
              <div className="aspect-[4/5] rounded-2xl overflow-hidden shadow-2xl">
                <img
                  src="https://images.pexels.com/photos/262047/pexels-photo-262047.jpeg?auto=compress&cs=tinysrgb&w=800"
                  alt="Fine dining at LUMA"
                  className="w-full h-full object-cover hover:scale-105 transition-transform duration-700"
                />
              </div>
              <div className="absolute -bottom-8 -right-8 w-48 h-48 rounded-2xl bg-gold-500/10 -z-10" />
              <div className="absolute -top-8 -left-8 w-32 h-32 rounded-full bg-charcoal-900/5 -z-10" />
            </div>
          </div>
          <div className="order-1 lg:order-2">
            <p className="text-gold-600 font-medium tracking-[0.2em] uppercase text-sm mb-4">Our Story</p>
            <h2 className="font-display text-4xl md:text-5xl lg:text-6xl font-bold text-charcoal-900 mb-6 leading-tight">
              A Culinary<br /><span className="text-gold-600">Journey</span>
            </h2>
            <p className="text-charcoal-600 text-lg leading-relaxed mb-8">
              Located near the Go Bus Station in Hurghada, LUMA has become a premier destination for discerning diners seeking an exceptional culinary experience. Our philosophy centers on blending Mediterranean influences with the freshest local ingredients.
            </p>
            <p className="text-charcoal-600 text-lg leading-relaxed mb-10">
              With a stylish yet relaxed atmosphere, we create the perfect setting for intimate dinners, celebratory gatherings, or simply enjoying expertly crafted cocktails with friends.
            </p>
            <div className="grid sm:grid-cols-3 gap-8">
              {features.map((feature, index) => (
                <div key={index} className="group">
                  <div className="text-gold-500 mb-4 group-hover:scale-110 transition-transform duration-300">{feature.icon}</div>
                  <h3 className="font-semibold text-charcoal-900 mb-2">{feature.title}</h3>
                  <p className="text-charcoal-500 text-sm">{feature.description}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

function MenuSection() {
  const menuItems = [
    { category: 'Popular', name: 'Muhammara', description: 'Roasted red pepper & walnut dip served with warm flatbread', price: 'E£185', image: 'https://images.pexels.com/photos/1640777/pexels-photo-1640777.jpeg?auto=compress&cs=tinysrgb&w=600', tag: 'Chef Recommended' },
    { category: 'Signature', name: 'Orange Lamb', description: 'Slow-cooked lamb shank with orange glaze and seasonal vegetables', price: 'E£485', image: 'https://images.pexels.com/photos/2474661/pexels-photo-2474661.jpeg?auto=compress&cs=tinysrgb&w=600', tag: 'Most Popular' },
    { category: 'Dessert', name: 'Date Cake', description: 'Moist date cake with caramel sauce and vanilla bean ice cream', price: 'E£165', image: 'https://images.pexels.com/photos/19989195/pexels-photo-19989195.jpeg?auto=compress&cs=tinysrgb&w=600', tag: 'Must Try' },
    { category: 'Appetizer', name: 'Slow Cooked Beef', description: 'Tender beef brisket with chimichurri and crispy shallots', price: 'E£275', image: 'https://images.pexels.com/photos/769289/food-meat-restaurant-beefsteak-769289.jpeg?auto=compress&cs=tinysrgb&w=600', tag: null },
    { category: 'Dessert', name: 'Halva Mousse', description: 'Light and creamy halva mousse with honey drizzle and pistachios', price: 'E£155', image: 'https://images.pexels.com/photos/1414234/pexels-photo-1414234.jpeg?auto=compress&cs=tinysrgb&w=600', tag: 'New' },
    { category: 'Cocktails', name: 'Signature Martini', description: 'Handcrafted martini with premium gin and botanical essence', price: 'E£145', image: 'https://images.pexels.com/photos/4049699/pexels-photo-4049699.jpeg?auto=compress&cs=tinysrgb&w=600', tag: 'Bar Favorite' },
  ];

  return (
    <section id="menu" className="py-24 lg:py-32 bg-charcoal-950 text-white">
      <div className="max-w-7xl mx-auto px-6 lg:px-8">
        <div className="text-center mb-16">
          <p className="text-gold-400 font-medium tracking-[0.2em] uppercase text-sm mb-4">Culinary Excellence</p>
          <h2 className="font-display text-4xl md:text-5xl lg:text-6xl font-bold mb-6">Our Menu</h2>
          <p className="text-charcoal-300 text-lg max-w-2xl mx-auto">
            A carefully curated selection of our finest dishes and cocktails, crafted with passion and precision
          </p>
        </div>
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {menuItems.map((item, index) => (
            <div
              key={index}
              className="group bg-charcoal-900/50 rounded-xl overflow-hidden border border-charcoal-800 hover:border-gold-500/30 transition-all duration-500 hover:shadow-xl hover:shadow-gold-500/10"
            >
              <div className="aspect-[4/3] overflow-hidden relative">
                <img src={item.image} alt={item.name} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700" />
                {item.tag && (
                  <span className="absolute top-4 left-4 bg-gold-500 text-charcoal-900 px-3 py-1 text-xs font-semibold rounded-sm">
                    {item.tag}
                  </span>
                )}
              </div>
              <div className="p-6">
                <span className="text-gold-400 text-xs uppercase tracking-wider">{item.category}</span>
                <h3 className="font-display text-xl font-semibold mt-2 mb-3 group-hover:text-gold-400 transition-colors">{item.name}</h3>
                <p className="text-charcoal-400 text-sm mb-4 line-clamp-2">{item.description}</p>
                <div className="flex items-center justify-between">
                  <span className="text-gold-400 font-semibold text-lg">{item.price}</span>
                  <button className="text-gold-400 hover:text-gold-300 text-sm font-medium flex items-center gap-1 group/btn">
                    View Details
                    <ArrowRight size={14} className="group-hover/btn:translate-x-1 transition-transform" />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
        <div className="text-center mt-12">
          <p className="text-charcoal-400 text-sm">Prices are approximate and may vary. Please ask your server for the complete menu.</p>
        </div>
      </div>
    </section>
  );
}

function Reviews() {
  const reviews = [
    { name: 'Natalia Contreras', role: 'Local Guide', rating: 5, text: 'We had a really great experience at Luma. The atmosphere is very chilled, stylish and aesthetic, it feels relaxed but still special enough for a nice evening out. The staff were attentive without being intrusive, and the food was absolutely delicious.', avatar: 'https://images.pexels.com/photos/762020/pexels-photo-762020.jpeg?auto=compress&cs=tinysrgb&w=150' },
    { name: 'Elena M.', role: 'Regular Guest', rating: 5, text: 'Very delicious food and good service! The atmosphere is nice and chill. Look out for portion sizes, they are very big, so you might want to share a main and an appetizer! Great value for the quality.', avatar: 'https://images.pexels.com/photos/1239291/pexels-photo-1239291.jpeg?auto=compress&cs=tinysrgb&w=150' },
    { name: 'Stewart', role: 'Local Guide', rating: 5, text: 'A "must visit" restaurant and bar during your stay in El Gouna. Highly advise and recommend a reservation during busy peak periods. The ambience, layout and above all, the staff, make this establishment a great place to dine at.', avatar: 'https://images.pexels.com/photos/220453/pexels-photo-220453.jpeg?auto=compress&cs=tinysrgb&w=150' },
    { name: 'Ahmed K.', role: 'Food Enthusiast', rating: 5, text: 'The Orange Lamb is absolutely incredible - melt-in-your-mouth perfect. The cocktails are expertly crafted and the live music creates such a wonderful atmosphere. LUMA has become our go-to spot for special occasions.', avatar: 'https://images.pexels.com/photos/1222271/pexels-photo-1222271.jpeg?auto=compress&cs=tinysrgb&w=150' },
  ];

  const stats = [
    { value: '4.7', label: 'Rating' },
    { value: '415+', label: 'Reviews' },
    { value: '127', label: 'Monthly Visitors' },
  ];

  return (
    <section id="reviews" className="py-24 lg:py-32 bg-cream-100">
      <div className="max-w-7xl mx-auto px-6 lg:px-8">
        <div className="text-center mb-16">
          <p className="text-gold-600 font-medium tracking-[0.2em] uppercase text-sm mb-4">Testimonials</p>
          <h2 className="font-display text-4xl md:text-5xl lg:text-6xl font-bold text-charcoal-900 mb-6">What Our Guests Say</h2>
          <div className="flex items-center justify-center gap-8 mb-8">
            {stats.map((stat, index) => (
              <div key={index} className="text-center">
                <div className="font-display text-3xl md:text-4xl font-bold text-gold-600">{stat.value}</div>
                <div className="text-charcoal-500 text-sm">{stat.label}</div>
              </div>
            ))}
          </div>
          <div className="flex justify-center gap-1 mb-8">
            {[1, 2, 3, 4, 5].map((star) => (
              <Star key={star} size={24} className="text-gold-500 fill-gold-500" />
            ))}
          </div>
        </div>
        <div className="grid md:grid-cols-2 gap-8">
          {reviews.map((review, index) => (
            <div key={index} className="bg-white rounded-2xl p-8 shadow-sm hover:shadow-xl transition-all duration-300 border border-charcoal-100">
              <div className="flex items-start gap-4 mb-6">
                <img src={review.avatar} alt={review.name} className="w-14 h-14 rounded-full object-cover" />
                <div>
                  <h4 className="font-semibold text-charcoal-900">{review.name}</h4>
                  <p className="text-charcoal-500 text-sm">{review.role}</p>
                </div>
                <div className="ml-auto flex gap-0.5">
                  {[1, 2, 3, 4, 5].map((star) => (
                    <Star key={star} size={16} className="text-gold-500 fill-gold-500" />
                  ))}
                </div>
              </div>
              <p className="text-charcoal-600 leading-relaxed">"{review.text}"</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

function Contact() {
  const hours = [
    { day: 'Monday - Thursday', time: '12:00 PM - 12:00 AM' },
    { day: 'Friday - Saturday', time: '12:00 PM - 1:00 AM' },
    { day: 'Sunday', time: '12:00 PM - 12:00 AM' },
  ];

  return (
    <section id="contact" className="py-24 lg:py-32 bg-charcoal-950 text-white">
      <div className="max-w-7xl mx-auto px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-16">
          <div>
            <p className="text-gold-400 font-medium tracking-[0.2em] uppercase text-sm mb-4">Visit Us</p>
            <h2 className="font-display text-4xl md:text-5xl lg:text-6xl font-bold mb-6">Make a Reservation</h2>
            <p className="text-charcoal-300 text-lg mb-10 leading-relaxed">
              Experience fine dining at its best. Reserve your table today and let us create an unforgettable evening for you.
            </p>
            <div className="space-y-6">
              <div className="flex items-start gap-4">
                <div className="bg-gold-500/10 p-3 rounded-lg"><MapPin className="text-gold-400" size={24} /></div>
                <div>
                  <h4 className="font-semibold text-white mb-1">Location</h4>
                  <p className="text-charcoal-400">Near the Go Bus Station, Hurghada 2,<br />Red Sea Governorate 84513</p>
                </div>
              </div>
              <div className="flex items-start gap-4">
                <div className="bg-gold-500/10 p-3 rounded-lg"><Phone className="text-gold-400" size={24} /></div>
                <div>
                  <h4 className="font-semibold text-white mb-1">Phone</h4>
                  <a href="tel:+201288883307" className="text-charcoal-400 hover:text-gold-400 transition-colors">012 8888 3307</a>
                </div>
              </div>
              <div className="flex items-start gap-4">
                <div className="bg-gold-500/10 p-3 rounded-lg"><Clock className="text-gold-400" size={24} /></div>
                <div>
                  <h4 className="font-semibold text-white mb-2">Hours</h4>
                  <div className="space-y-1">
                    {hours.map((item, index) => (
                      <div key={index} className="flex gap-8 text-charcoal-400 text-sm">
                        <span className="w-36">{item.day}</span>
                        <span>{item.time}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
            <div className="flex gap-4 mt-10">
              <a href="tel:+201288883307" className="flex-1 bg-gold-500 hover:bg-gold-600 text-charcoal-900 px-6 py-4 rounded-sm font-semibold tracking-wide transition-all duration-300 text-center hover:shadow-lg hover:shadow-gold-500/20">
                Call Now
              </a>
              <a href="https://instagram.com" target="_blank" rel="noopener noreferrer" className="flex-1 border-2 border-charcoal-700 hover:border-gold-400 text-white px-6 py-4 rounded-sm font-semibold tracking-wide transition-all duration-300 flex items-center justify-center gap-2 hover:bg-charcoal-900">
                <Instagram size={20} /> Follow Us
              </a>
            </div>
          </div>
          <div className="grid sm:grid-cols-2 lg:grid-cols-1 gap-4">
            <div className="aspect-square lg:aspect-auto lg:min-h-[280px] rounded-2xl overflow-hidden">
              <img src="https://images.pexels.com/photos/2871750/pexels-photo-2871750.jpeg?auto=compress&cs=tinysrgb&w=800" alt="Restaurant interior" className="w-full h-full object-cover hover:scale-105 transition-transform duration-500" />
            </div>
            <div className="aspect-square lg:aspect-auto lg:min-h-[280px] rounded-2xl overflow-hidden">
              <img src="https://images.pexels.com/photos/2610473/pexels-photo-2610473.jpeg?auto=compress&cs=tinysrgb&w=800" alt="Bar area" className="w-full h-full object-cover hover:scale-105 transition-transform duration-500" />
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

function Footer() {
  return (
    <footer className="bg-charcoal-950 border-t border-charcoal-800">
      <div className="max-w-7xl mx-auto px-6 lg:px-8 py-12">
        <div className="flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="font-display text-2xl font-bold text-white">LUMA</div>
          <p className="text-charcoal-500 text-sm text-center">© {new Date().getFullYear()} LUMA Restaurant. All rights reserved.</p>
          <div className="flex items-center gap-6">
            <a href="https://instagram.com" target="_blank" rel="noopener noreferrer" className="text-charcoal-400 hover:text-gold-400 transition-colors"><Instagram size={20} /></a>
            <a href="tel:+201288883307" className="text-charcoal-400 hover:text-gold-400 transition-colors"><Phone size={20} /></a>
            <a href="https://maps.google.com" target="_blank" rel="noopener noreferrer" className="text-charcoal-400 hover:text-gold-400 transition-colors"><MapPin size={20} /></a>
          </div>
        </div>
      </div>
    </footer>
  );
}
