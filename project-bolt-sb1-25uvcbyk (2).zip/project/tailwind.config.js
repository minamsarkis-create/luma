/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      colors: {
        gold: {
          50: '#FFF9E6',
          100: '#FFF0B3',
          200: '#FFE680',
          300: '#FFD94D',
          400: '#FFCC1A',
          500: '#E6B800',
          600: '#B38F00',
          700: '#806600',
          800: '#4D3D00',
          900: '#1A1400',
        },
        charcoal: {
          50: '#F6F6F7',
          100: '#E2E2E4',
          200: '#C4C4C8',
          300: '#A3A3A9',
          400: '#82828A',
          500: '#68686F',
          600: '#54545A',
          700: '#46464B',
          800: '#3D3D41',
          900: '#1A1A1D',
          950: '#0D0D0F',
        },
        cream: {
          50: '#FEFDFB',
          100: '#FDF8F0',
          200: '#FAF0E1',
          300: '#F6E7CE',
          400: '#F0D9B5',
        },
      },
      fontFamily: {
        display: ['Playfair Display', 'serif'],
        sans: ['Inter', 'sans-serif'],
      },
    },
  },
  plugins: [],
};
